import { getId } from '@/common/utils/index.ts';
import { type ReactNode } from 'react';
import { MemoizedCell } from '../Cell/Cell.tsx';
import styles from './Row.module.scss';

type RowProps = {
  rowData: Record<string, string>;
  rowKey: string;
  header?: boolean;
};

const Row = ({ rowData, header, rowKey: _ }: RowProps): ReactNode => {
  return (
    <tr className={styles.row}>
      {Object.entries(rowData).map(([_, value]) => {
        const cellKey = getId(); //`${rowKey}_${key}`;
        return <MemoizedCell value={value} key={cellKey} cellKey={cellKey} header={header} />;
      })}
    </tr>
  );
};

export const MemoizedRow = Row; //memo(Row);
